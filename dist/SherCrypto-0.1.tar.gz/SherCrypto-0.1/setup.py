from distutils.core import setup
setup(
    name = 'SherCrypto',
    packages = ['SherCrypto'],
    version = '0.1',
    description = 'Python Console Cryptography Tool',
    author = 'Timothy Sherry',
    author_email = 'timsherry97@gmail.com',
    url = 'github.com/timothy1997/SherCrypto',
    keywords = ['Python', 'Encryption', 'Decryption', 'Cryptography', 'Tool', 'AES', 'Advanced', 'Encryption', 'Standard'],
    classifiers = [],
)
