print('This is foo.py')
